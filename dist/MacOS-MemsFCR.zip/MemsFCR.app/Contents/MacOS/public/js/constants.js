const IdleSpeedAdjustment = "idlespeed"
const IdleHotAdjustment = "idlehot"
const FuelTrimAdjustment = "fueltrim"
const IgnitionAdvanceAdjustment = "ignitionadvance"